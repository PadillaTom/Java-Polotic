
package Logica;

import IGU.InterfazPrincipal;

public class Main {
   public static void main(String[] args){
       InterfazPrincipal interfaz = new InterfazPrincipal();
       
       interfaz.setVisible(true);
       interfaz.setLocationRelativeTo(null);
   } 
}
