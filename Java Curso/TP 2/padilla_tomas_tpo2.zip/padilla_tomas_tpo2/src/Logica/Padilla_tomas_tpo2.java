package Logica;

import IGU.PantallaCarga;

public class Padilla_tomas_tpo2 {
   
    public static void main(String[] args) {
        // *** IGU ***
        PantallaCarga myScreen = new PantallaCarga();
        myScreen.setVisible(true);
        myScreen.setLocationRelativeTo(null);
        
        
    }
    
}
